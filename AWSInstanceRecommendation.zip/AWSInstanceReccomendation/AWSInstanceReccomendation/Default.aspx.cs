﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AWSInstanceReccomendation
{
    public partial class Default : System.Web.UI.Page
    {
       
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        protected void TextBox4_TextChanged(object sender, EventArgs e)
        {

        }

        protected void resultView_TextChanged(object sender, EventArgs e)
        {

        }

        public void onClickCalculate(object sender, EventArgs e)
        {
            try
            {
               
                string ap_nwp1 = nwp_ap.Text;
                string eu_nwp1 = nwp_eu.Text;
                string ap_cpu1 = cpu_ap.Text;
                string eu_cpu1 = cpu_eu.Text;
                string ap_nw1 = nw_ap.Text;
                string eu_nw1 = nw_eu.Text;


                double ap_nwp = Convert.ToDouble(ap_nwp1);
                double eu_nwp = Convert.ToDouble(eu_nwp1);
                double ap_cpu = Convert.ToDouble(ap_cpu1);
                double eu_cpu = Convert.ToDouble(eu_cpu1);
                double ap_nw = Convert.ToDouble(ap_nw1);
                double eu_nw = Convert.ToDouble(eu_nw1);

                int y=1, z=2;

                while (y != z)
                {
                    if (eu_nw >= ap_nw)
                    {
                        if (eu_nwp >= ap_nwp && ap_cpu >= eu_cpu)
                        {
                            string str1 = "Europe Server is working better than Asian servers and price for bidding will be $ 0.047270";
                            lblResult.Text = str1;
                            lblResult.Visible = true;

                            y = 2;
                            break;
                        }
                        else
                        {
                            string str2 = "Europe Server is working better than Asian server and price for bidding will be $ 0.047270";
                            lblResult.Text = str2;
                            lblResult.Visible = true;
                            y = 2;
                        }
                    }
                    else if(y!=2)
                    {
                        string str3 = "Asian Server is working better than Europe server and price for bidding will be $ 0.035331";
                        lblResult.Text = str3;
                        lblResult.Visible = true;
                        break;
                    }
                }



                
            }
            catch (Exception ex)
            {
                throw ex;
            }


        }

    }
}